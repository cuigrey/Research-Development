### Installed products
- Visual Studio: [example Professional 2015 Update 1]

### Description
Replace this text with a short description

### Steps to recreate
1. Replace this
2. text with 
3. the steps
4. to recreate

### Current behavior
Explain what it's doing and why it's wrong

### Expected behavior
Explain what it should be doing after it's fixed.
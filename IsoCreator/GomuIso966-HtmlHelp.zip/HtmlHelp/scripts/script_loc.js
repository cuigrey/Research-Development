
//NEW FEEDBACK SYSTEM
L_feedBackSend = "Send";
L_feedBack = "feedback";
L_feedBackText = " on this topic to Microsoft.";
L_FeedBackDivID = "fb";
L_fbintroduction = "We value your feedback. To rate this topic and send feedback about this topic to the documentation team, click a rating, and then click <b>Send Feedback</b>. For assistance with support issues, refer to the technical support information included with the product.";
L_fbsend = "Send Feedback";
L_fbaltsend = "Send feedback";
L_fb1Poor = "Poor";
L_fb1Excellent = "Outstanding";
L_fb1EnterFeedbackHere_Text = "To e-mail your feedback, click here:";
L_fb1Title_Text = "Documentation Feedback";
L_fbaltIcon = "Display feedback instructions at the bottom of the page."



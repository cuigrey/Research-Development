namespace ISO9660.Enums {

	internal enum Endian {
		LittleEndian,
		BigEndian
	};

}
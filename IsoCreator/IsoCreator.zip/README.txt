Bunny Eating Rabbit - Iso Creator

All the information about the code can be found within the project. I also included here a file containing the structure of the ISO 9660 file structure.

For any suggestion, question etc. please write to me at florin_chelaru@yahoo.com, and I will answer as soon and as clarifying as possible.

Also, don't hesitate so send feedback. I would really apreciate it, and it's of great use to me, as I am sure there still are some bugs in the project.

Hope you find it useful and feel free to use it in any way you choose.